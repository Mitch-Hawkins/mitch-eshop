// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCXhwrE354aGtVD3Ozbid8J1AQix3D0cMM",
  authDomain: "mitch-eshop-firestore.firebaseapp.com",
  projectId: "mitch-eshop-firestore",
  storageBucket: "mitch-eshop-firestore.appspot.com",
  messagingSenderId: "433199273372",
  appId: "1:433199273372:web:cd5978d00179ceeaa52459",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app); //this is an extra step remember
